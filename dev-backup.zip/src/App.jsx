import React from 'react'

const App = () => {
    return (
        <>
            <h1 className='font-bold underline'>Shehroz hassan</h1>
            <h2>saddam hassan</h2>
            <h3>Ikram hassan</h3>
        </>
    )
}

export default App